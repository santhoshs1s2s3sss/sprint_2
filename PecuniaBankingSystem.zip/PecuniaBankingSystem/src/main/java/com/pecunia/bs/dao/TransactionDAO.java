package com.pecunia.bs.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.pecunia.bs.dto.Transaction;
public interface TransactionDAO extends JpaRepository<Transaction,Integer>
{

}
