package com.pecunia.bs.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.pecunia.bs.dto.Transaction;
//import com.pecunia.bs.service.AccountService;
//import com.pecunia.bs.service.CustomerService;
import com.pecunia.bs.service.TransactionService;
@RestController
public class AccountController 
{
    @Autowired
    TransactionService transactionService;
    public void setTransactionService(TransactionService transactionService) { 
    	this.transactionService = transactionService;
    	}
    
     @PostMapping(value="/addTransaction",consumes="application/json")
    public ResponseEntity<String> addTransactionDetails(@RequestBody Transaction transaction)
    {
    	try
    	{
    		this.transactionService.insertTransaction(transaction);
    		return new ResponseEntity<String>("Transaction SuccessFull",HttpStatus.OK);
    	}
    	catch(Exception ex)
    	{
    		return new ResponseEntity<String>("Transaction Failed",HttpStatus.BAD_REQUEST);
    	}
    }
}
