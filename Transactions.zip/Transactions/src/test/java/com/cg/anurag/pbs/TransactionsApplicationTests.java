package com.cg.anurag.pbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
